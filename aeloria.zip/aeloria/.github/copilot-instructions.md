# Copilot Instructions

## Project Guidelines
- Project security requirement: any elevated Warden/admin mode must be owner-only, configured locally, and application-level rather than granting Discord Administrator to the bot.
- The game server is named "The Forgotten Ring," and the world/lore identity is "Aeloria" unless specified otherwise.

## Development Instructions
- When asked to resume or build the project, implement the changes in the workspace and validate them instead of only describing the work.